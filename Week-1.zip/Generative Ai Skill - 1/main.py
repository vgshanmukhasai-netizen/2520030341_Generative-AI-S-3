import os
from dotenv import load_dotenv
from google import genai

# Load API key
load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError("Gemini API key not found!")

# Connect to Gemini
client = genai.Client(api_key=api_key)

# Send prompt
response = client.models.generate_content(
    model="gemini-3.5-flash-lite",
    contents="What is Generative AI? Explain in simple words."
)

# Display response
print("\nGemini Response:")
print(response.text)