WEEK 2 - GENERATIVE AI APPLICATION

1. Revoke the API key that was previously shared/exposed.
2. Copy .env.example and rename the copy to .env.
3. Paste your NEW Gemini API key after GEMINI_API_KEY=.
4. Install dependencies:
       uv sync
   Or:
       pip install -r requirements.txt
5. Test Gemini:
       uv run python test_client.py
   Or:
       python test_client.py
6. Run the chatbot:
       uv run python main.py
   Or:
       python main.py

Do not upload .env to GitHub or share screenshots containing the key.
The project uses the Gemini model ID gemini-3.8-flash.
