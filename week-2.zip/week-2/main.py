import os
from dotenv import load_dotenv
from llm_client import GeminiProvider

load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError("GEMINI_API_KEY not found in .env file")


def main():
    print("===== WEEK 2: GENERATIVE AI APPLICATION =====")

    try:
        llm = GeminiProvider(api_key)

        print("\nGemini AI is ready!")
        print("Type 'exit' to quit.")

        while True:
            question = input("\nYou: ").strip()

            if question.lower() == "exit":
                print("Thank you! Goodbye.")
                break

            if not question:
                print("Please enter a question.")
                continue

            try:
                print("\nGemini is thinking...")
                response = llm.generate(question)
                print("\nGemini:", response)

            except Exception as e:
                print("\nError:", e)

    except Exception as e:
        print("Initialization Error:", e)


if __name__ == "__main__":
    main()