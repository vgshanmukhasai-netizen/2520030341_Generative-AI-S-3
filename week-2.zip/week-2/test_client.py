import os

from dotenv import load_dotenv

from llm_client import GeminiProvider, LLMClient

load_dotenv()


def test_gemini_connection():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY was not found. Check your .env file."
        )

    print("Connecting to Gemini...")
    provider = GeminiProvider(api_key)
    client = LLMClient(provider)

    print("Sending test message...")
    answer = client.generate("Reply with: Gemini connection successful.")

    print("\nGemini response:")
    print(answer)


if __name__ == "__main__":
    try:
        test_gemini_connection()
    except Exception as exc:
        print(f"\nTEST FAILED: {exc}")
